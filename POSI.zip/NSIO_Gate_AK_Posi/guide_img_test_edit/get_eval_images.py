import tensorflow as tf
import numpy as np
from PIL import Image
import pdb
import os

def build_edit_image_tfrd():
	all_images = os.listdir('./raw_images/')
	writer = tf.python_io.TFRecordWriter('val_data.tfr')

	for i in range(len(all_images)):
		edit_img = Image.open('edited_images/' + all_images[i]).convert('RGB')
		raw_img = Image.open('raw_images/' + all_images[i]).convert('RGB')
		
		edit_array = np.array(edit_img)
		edit_array = np.mean(edit_img, axis=2)
		edit = ((edit_array==0) * 255).astype(np.uint8)
		edit_sketch = Image.fromarray(edit[:,:])
		#edit_sketch.save('test.png')
		#raw_img.save('test_ori.png')
		#pdb.set_trace()
		fea_dict = dict()
		raw_bytes = raw_img.tobytes()
		sketch_bytes = edit_sketch.tobytes()

		fea_dict['images'] = tf.train.Feature(bytes_list = tf.train.BytesList(value=[raw_bytes]))
		fea_dict['sketch'] = tf.train.Feature(bytes_list = tf.train.BytesList(value=[sketch_bytes]))

		tf_features = tf.train.Features(feature=fea_dict)
		tf_example = tf.train.Example(features=tf_features)

		tf_serialized = tf_example.SerializeToString()

		writer.write(tf_serialized)

	writer.close()

if __name__ == '__main__':
	build_edit_image_tfrd()
