python train_model.py  --trainset-path ../NSIO_Gate_ori/data/train_sketch.tfr --testset-path ../NSIO_Gate_ori/data/test_sketch.tfr  --checkpoint-path ./logs/9_5_10/models/-100
