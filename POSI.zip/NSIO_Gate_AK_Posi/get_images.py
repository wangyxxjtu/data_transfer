import tensorflow as tf
import os
from dataset.parse import parse_trainset, parse_testset
from tqdm import trange
import numpy as np
from PIL import Image
import random
import pdb
def get_images(data_split):
	'''
	this script get the training and test images 
	'''
	path = './data/tf_records/{}set.tfr'.format(data_split)
	dataset = tf.data.TFRecordDataset(filenames=[path])
	if 'train' in data_split:
		dataset = dataset.map(parse_trainset, num_parallel_calls=8)
		data_length = 5040
		size = 186624
	else:
		dataset = dataset.map(parse_testset, num_parallel_calls=8)
		data_length = 2000
		size = 98304
	dataset = dataset.batch(1).repeat()

	data_iterator = dataset.make_one_shot_iterator()
	im = data_iterator.get_next()
	
	data_mat = np.zeros((data_length, size))
	with tf.Session() as sess:
		for i in trange(data_length):
			img = sess.run(im)
			data_mat[i] = img[0]
	
	data_mat = data_mat.astype(np.uint8)
	np.save('data/{}.npy'.format(data_split), data_mat)
	pdb.set_trace()

def images_for_guide(data_split, count=20):
	random.seed(2019)
	tf.set_random_seed(2019)
	output = './guide_img_test/'
	if not os.path.exists(output):
		os.makedirs(output)

	path = './data/{}_sketch.tfr'.format(data_split)
	dataset = tf.data.TFRecordDataset(filenames=[path])
	length = 5040 if data_split=='train' else 2000

	dataset = dataset.shuffle(length)

	if 'train' in data_split:
		dataset = dataset.map(parse_trainset, num_parallel_calls=8)
		data_length = 5040
		size = 186624
	else:
		dataset = dataset.map(parse_testset, num_parallel_calls=8)
		data_length = 2000
		size = 98304
	dataset = dataset.batch(1).repeat()

	data_iterator = dataset.make_one_shot_iterator()
	im,sketch = data_iterator.get_next()
	
	with tf.Session() as sess:
		for i in trange(count):
			img,sketch_im = sess.run([im, sketch])
			img = ((img[0]+1)/2. * 255).astype(np.uint8)
			
			sketch_im  = (sketch_im[0] * 255.).astype(np.uint8)
			image = Image.fromarray(img)
			sketch_image = Image.fromarray(sketch_im[:,:,0])

			image.save(os.path.join(output, data_split+'_'+str(i+1)+'.png'))
			sketch_image.save(os.path.join(output, data_split+'_sk'+str(i+1)+'.png'))
		
if __name__ =='__main__':
	#get_images('train')
	images_for_guide('test')
