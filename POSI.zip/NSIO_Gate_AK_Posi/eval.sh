#python eval_model.py --trainset-path ./data/train_sketch.tfr --testset-path ./data/test_sketch.tfr --checkpoint-path ./logs/0818/2/models/-60602
date='8_30_13'
model_name='272'
use_gpus=0
gen_mode='m0'

python eval_model.py --trainset-path ./data/train_sketch.tfr --testset-path ./data/test_sketch.tfr --checkpoint-path ./logs/$date/models/-$model_name --use_gpus $use_gpus --val

#python eval_fid_is_score.py --gen_image_path ./logs/$date/results_test/$model_name/ --use_gpus $use_gpus --gen_mode $gen_mode 
