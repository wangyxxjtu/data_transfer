import tensorflow as tf
import numpy as np
from PIL import Image
import os
import pdb
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

def parse_trainset(example_proto):

	dics = {}
	dics['image'] = tf.FixedLenFeature(shape=[], dtype=tf.string)
	dics['sketch'] = tf.FixedLenFeature(shape=[], dtype=tf.string)

	parsed_example = tf.parse_single_example(
	    serialized=example_proto, features=dics)
	image = tf.decode_raw(parsed_example['image'], out_type=tf.uint8)
	sketch = tf.decode_raw(parsed_example['sketch'], out_type=tf.uint8)

	image = tf.reshape(image, shape=[72 * 2, 216 * 2, 3])
	sketch = tf.reshape(sketch, shape=[72 * 2, 216 * 2])
	sketch = tf.expand_dims(sketch, axis=2)

	mul_channel = tf.concat([image, sketch],axis=-1)

	mul_channel = tf.random_crop(mul_channel, [64 * 2, 128 * 2, 4])
	mul_channel = tf.image.random_flip_left_right(mul_channel)
	mul_channel = tf.cast(mul_channel, tf.float32) / 255.
	mul_channel = 2. * mul_channel - 1.

	sketch = mul_channel[:,:,3:]
	pos = tf.ones_like(sketch)
	neg = -tf.ones_like(sketch)	
	sketch = tf.where(sketch<0.0, x=neg,y=pos)


	return mul_channel[:,:,:3], (sketch + 1) / 2.

def parse_testset(example_proto):

	dics = {}
	dics['image'] = tf.FixedLenFeature(shape=[], dtype=tf.string)
	dics['sketch'] = tf.FixedLenFeature(shape=[], dtype=tf.string)
	
	parsed_example = tf.parse_single_example(
	    serialized=example_proto, features=dics)
	image = tf.decode_raw(parsed_example['image'], out_type=tf.uint8)
	sketch = tf.decode_raw(parsed_example['sketch'], out_type=tf.uint8)

	image = tf.reshape(image, shape=[64 * 2, 128 * 2, 3])
	sketch = tf.reshape(sketch, shape=[128, 256])
	sketch = tf.expand_dims(sketch, axis=2)


	image = tf.cast(image, tf.float32) * (2. / 255) - 1.0
	sketch = tf.cast(sketch, tf.float32) * (2. / 255) - 1.0

	pos = tf.ones_like(sketch)
	neg = -tf.ones_like(sketch)	
	sketch = tf.where(sketch<0.0, x=neg,y=pos)

	return image, (sketch + 1) / 2.

def parse_valset(example_proto):

	dics = {}
	dics['images'] = tf.FixedLenFeature(shape=[], dtype=tf.string)
	dics['sketch'] = tf.FixedLenFeature(shape=[], dtype=tf.string)
	
	parsed_example = tf.parse_single_example(
	    serialized=example_proto, features=dics)
	image = tf.decode_raw(parsed_example['images'], out_type=tf.uint8)
	sketch = tf.decode_raw(parsed_example['sketch'], out_type=tf.uint8)

	image = tf.reshape(image, shape=[64 * 2, 128 * 2, 3])
	sketch = tf.reshape(sketch, shape=[128, 256])
	sketch = tf.expand_dims(sketch, axis=2)


	image = tf.cast(image, tf.float32) * (2. / 255) - 1.0
	sketch = tf.cast(sketch, tf.float32) * (2. / 255) - 1.0

	pos = tf.ones_like(sketch)
	neg = -tf.ones_like(sketch)	
	sketch = tf.where(sketch<0.0, x=neg,y=pos)

	return image, (sketch + 1) / 2.

if __name__ == '__main__':
	data_path = '../data/train_sketch.tfr'
	trainset = tf.data.TFRecordDataset(filenames=[data_path])
	#trainset = trainset.shuffle(args.trainset_length)
	trainset = trainset.map(parse_trainset, num_parallel_calls=2)
	trainset = trainset.batch(32).repeat()

	train_iterator = trainset.make_one_shot_iterator()
	train_im, train_sketch = train_iterator.get_next()

	with tf.Session() as sess:
		img, sketch = sess.run([train_im, train_sketch])
		
		image = (img[0] + 1) /2
		image = (image * 255).astype(np.uint8)
		Image.fromarray(image).save('ori.png')
		
		sk_img = (sketch[0, :,:,0] + 1) /2
		sk_img = (sk_img * 255).astype(np.uint8)
		Image.fromarray(sk_img).save('test.png')

		pdb.set_trace()
		print(sketch, sketch.shape)
