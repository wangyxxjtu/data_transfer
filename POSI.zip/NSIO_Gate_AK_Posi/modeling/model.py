import tensorflow as tf
import tensorflow.contrib.layers as ly
from tensorflow.contrib.framework.python.ops import add_arg_scope
from neuralgym.ops.layers import resize
import tensorflow.contrib.rnn as crnn
import numpy as np
from sn import spectral_normed_weight
import os
import pdb

class Model():
	def __init__(self, cfg):
		self.cfg = cfg

	def new_atrous_conv_layer(self, bottom, filter_shape, rate, name=None):
		with tf.variable_scope(name):
			regularizer = tf.contrib.layers.l2_regularizer(self.cfg.weight_decay)
			initializer = tf.contrib.layers.xavier_initializer()
			W = tf.get_variable(
				"W",
				shape=filter_shape,
				regularizer=regularizer,
				initializer=initializer)

			x = tf.nn.atrous_conv2d(
				bottom, W, rate, padding='SAME')
		return x

	def identity_block(self, X_input, kernel_size, filters, stage, block, is_relu=False):

		if is_relu:
			activation_fn=tf.nn.relu
		else:
			activation_fn=self.leaky_relu

		normalizer_fn = ly.instance_norm

		# defining name basis
		conv_name_base = 'res' + str(stage) + block + '_branch'

		with tf.variable_scope("id_block_stage" + str(stage) + block):
			filter1, filter2, filter3 = filters
			X_shortcut = X_input
			regularizer = tf.contrib.layers.l2_regularizer(self.cfg.weight_decay)
			initializer = tf.contrib.layers.xavier_initializer()

			# First component of main path
			x = self.gated_conv(X_input,cnum=filter1, ksize=1, stride=1, 
					name=conv_name_base+'2a', regularizer=regularizer, 
					initializer=initializer)
			x = normalizer_fn(x)
			x = activation_fn(x)

			# Second component of main path
			x = self.gated_conv(x, cnum=filter2, ksize=kernel_size, 
					name=conv_name_base+'2b', regularizer=regularizer, 
					initializer=initializer)
			x = normalizer_fn(x)
			x = activation_fn(x)

			# Third component of main path
			x = self.gated_conv(x, cnum=filter3, ksize=1, name=conv_name_base+'2c',
					regularizer=regularizer, initializer=initializer)
			x = normalizer_fn(x)

			# Final step: Add shortcut value to main path, and pass it through
			x = tf.add(x, X_shortcut)
			x = activation_fn(x)

		return x

	def convolutional_block(self, X_input, kernel_size, filters, stage, block, stride=2, is_relu=False):
		
		if is_relu:
			activation_fn=tf.nn.relu
			
		else:
			activation_fn=self.leaky_relu

		normalizer_fn = ly.instance_norm

		# defining name basis
		conv_name_base = 'res' + str(stage) + block + '_branch'

		with tf.variable_scope("conv_block_stage" + str(stage) + block):

			regularizer = tf.contrib.layers.l2_regularizer(self.cfg.weight_decay)
			initializer = tf.contrib.layers.xavier_initializer()

			# Retrieve Filters
			filter1, filter2, filter3 = filters

			# Save the input value
			X_shortcut = X_input

			# First component of main path
			x = self.gated_conv(X_input, cnum=filter1, ksize=1, stride=1,
					name=conv_name_base+'2a', regularizer=regularizer, 
					initializer=initializer)
			x = normalizer_fn(x)
			x = activation_fn(x)

			# Second component of main path
			x = self.gated_conv(x, cnum=filter2, ksize=kernel_size, stride=stride,
					name=conv_name_base+'2b', regularizer=regularizer,
					initializer=initializer)
			x = normalizer_fn(x)
			x = activation_fn(x)

			# Third component of main path
			x = self.gated_conv(x, cnum=filter3, ksize=1,stride=1,name=conv_name_base+'2c',
					regularizer=regularizer, initializer=initializer)
			x = normalizer_fn(x)

			# SHORTCUT PATH
			X_shortcut = self.gated_conv(X_shortcut, cnum=filter3, ksize=1, 
					stride=stride, name=conv_name_base+'1', 
					regularizer=regularizer, initializer=initializer)
			X_shortcut = normalizer_fn(X_shortcut)

			# Final step: Add shortcut value to main path, and pass it through
			# a RELU activation
			x = tf.add(X_shortcut, x)
			x = activation_fn(x)

		return x

	def leaky_relu(self, x, name=None, leak=0.2):
		f1 = 0.5 * (1 + leak)
		f2 = 0.5 * (1 - leak)
		return f1 * x + f2 * abs(x)

	def in_lrelu(self, x, name=None):
		x = tf.contrib.layers.instance_norm(x)
		x = self.leaky_relu(x)
		return x

	def in_relu(self, x, name=None):
		x = tf.contrib.layers.instance_norm(x)
		x = tf.nn.relu(x)
		
		return x

	def rct(self, x, sketch,  posi, name='rct', reuse=False, inverse_right=False):
		with tf.variable_scope(name, reuse=reuse):
			regularizer = tf.contrib.layers.l2_regularizer(self.cfg.weight_decay)
			output_size = x.get_shape().as_list()[3]
			size = 512
			layer_num = 2
			activation_fn = tf.tanh
			x = ly.conv2d(x, size, 1, stride=1, activation_fn=None,
									  normalizer_fn=None, padding='SAME', weights_regularizer=regularizer, biases_initializer=None)
			x = self.in_lrelu(x)
			x = tf.transpose(x, [0, 2, 1, 3])
			x = tf.reshape(x, [-1, 4, 4 * size])
			x = tf.transpose(x, [1, 0, 2])
			# encoder_inputs = x
			x = tf.reshape(x, [-1, 4 * size])
			x_split = tf.split(x, 4, 0)

			ys = []
			with tf.variable_scope('LSTM'):
					with tf.variable_scope('encoder'):
							lstm_cell = tf.contrib.rnn.LSTMCell(
									4 * size, activation=activation_fn)
							lstm_cell = tf.contrib.rnn.MultiRNNCell(
									[lstm_cell] * layer_num, state_is_tuple=True)
					
					init_state = lstm_cell.zero_state(self.cfg.batch_size_per_gpu, dtype=tf.float32)
					now, _state = lstm_cell(x_split[0], init_state)
					now, _state = lstm_cell(x_split[1], _state)
					now, _state = lstm_cell(x_split[2], _state)
					part_out, _part_state = lstm_cell(x_split[3], _state)
					if inverse_right:
						return part_out
					else:
						with tf.variable_scope('decoder'):
								lstm_cell = tf.contrib.rnn.BasicLSTMCell(
										4 * size, activation=activation_fn)
								lstm_cell2 = tf.contrib.rnn.MultiRNNCell(
										[lstm_cell] * layer_num, state_is_tuple=True)
						#predict
						#encode the sketch
						sk_enc = self.encode_sketch(sketch)
						sk_enc = tf.reshape(sk_enc,[-1, 4, 4*512])
					
						posi_enc = self.encode_posi(posi)
						posi_enc = tf.reshape(posi_enc, [-1, 4, 4*512])
						
						#encode the hidden state info to the hidden state
						c1 = _part_state[0].c + sk_enc[:,0,:] + posi_enc[:,0,:]
						h1 = _part_state[0].h + sk_enc[:,1, :] + posi_enc[:,1, :]
						c2 = _part_state[1].c + sk_enc[:,2,:] + posi_enc[:,2, :]
						h2 = _part_state[1].h + sk_enc[:,3,:] + posi_enc[:, 3, :]
						
						lstmtp1 = crnn.LSTMStateTuple(c=c1, h=h1)
						lstmtp2 = crnn.LSTMStateTuple(c=c2, h=h2)
						new_state_tuple = (lstmtp1, lstmtp2)

						now, _state = lstm_cell2(x_split[3], new_state_tuple)
						ys.append(tf.reshape(now, [-1, 4, 1, size]))
						now, _state = lstm_cell2(now, _state)
						ys.append(tf.reshape(now, [-1, 4, 1, size]))
						now, _state = lstm_cell2(now, _state)
						ys.append(tf.reshape(now, [-1, 4, 1, size]))
						now, _state = lstm_cell2(now, _state)
						ys.append(tf.reshape(now, [-1, 4, 1, size]))
			y = tf.concat(ys, axis=2)

			y = ly.conv2d(y, output_size, 1, stride=1, activation_fn=None,
									  normalizer_fn=None, padding='SAME', weights_regularizer=regularizer, biases_initializer=None)
			y = self.in_lrelu(y)
			
			return y, part_out
		
	def shc(self, x, shortcut, channels, name='shc'):
		regularizer = tf.contrib.layers.l2_regularizer(self.cfg.weight_decay)
		normalizer_fn = tf.contrib.layers.instance_norm
		initializer = ly.xavier_initializer()
		'''x = ly.conv2d(x, channels / 2, 1, stride=1, activation_fn=tf.nn.relu,
					  normalizer_fn=tf.contrib.layers.instance_norm, padding='SAME', weights_regularizer=regularizer)
		x = ly.conv2d(x, channels / 2, 3, stride=1, activation_fn=tf.nn.relu,
					  normalizer_fn=tf.contrib.layers.instance_norm, padding='SAME', weights_regularizer=regularizer)
		x = ly.conv2d(x, channels, 1, stride=1, activation_fn=None,
					  normalizer_fn=tf.contrib.layers.instance_norm, padding='SAME', weights_regularizer=regularizer)'''
		x = self.gated_conv_ly(x, cnum=channels/2, ksize=1, stride=1,
				normalizer=normalizer_fn, regularizer=regularizer, name=name+'a')
		
		x = self.gated_conv_ly(x, cnum=channels/2, ksize=3, stride=1,
				normalizer=normalizer_fn, regularizer=regularizer, name=name+'b')
		
		x = self.gated_conv_ly(x, cnum=channels, ksize=1, stride=1, activation=None,
				normalizer=normalizer_fn, regularizer=regularizer, name=name+'c')
		
		return tf.add(shortcut, x)


	def grb(self, x, filters, rate, name):
		activation_fn = tf.nn.relu
		normalizer_fn = ly.instance_norm
		shortcut = x
		x1 = self.new_atrous_conv_layer(x, [3, 1, filters, filters], rate, name+'_a1')
		x1 = normalizer_fn(x1)
		x1 = activation_fn(x1)
		x1 = self.new_atrous_conv_layer(x1, [1, 7, filters, filters], rate, name+'_a2')
		x1 = normalizer_fn(x1)

		x2 = self.new_atrous_conv_layer(x, [1, 7, filters, filters], rate, name+'_b1')
		x2 = normalizer_fn(x2)
		x2 = activation_fn(x2)
		x2 = self.new_atrous_conv_layer(x2, [3, 1, filters, filters], rate, name+'_b2')
		x2 = normalizer_fn(x2)

		x = tf.add(shortcut, x1)
		x = tf.add(x, x2)
		x = activation_fn(x)
		return x
	
	#encoder the sketch image
	def encode_sketch(self, sketch, reuse=None):
		with tf.variable_scope('GEN_ske', reuse=reuse):
			x=sketch
			normalizer_fn = ly.instance_norm
			regularizer = tf.contrib.layers.l2_regularizer(self.cfg.weight_decay)
			initializer = tf.contrib.layers.xavier_initializer()
			# stage 1
			x = tf.layers.conv2d(x, filters=64, kernel_size=(4, 4), strides=(
				2, 2), name='conv0', kernel_regularizer=regularizer, padding='same', kernel_initializer=initializer, use_bias=False)
			x = self.in_lrelu(x)
			x = tf.layers.conv2d(x, filters=128, kernel_size=(4, 4), strides=(
				2, 2), name='conv1', padding='same', kernel_regularizer=regularizer, kernel_initializer=initializer, use_bias=False)
			x = self.in_lrelu(x)

			# stage 2
			x = tf.layers.conv2d(x, filters=256, kernel_size=(4, 4), strides=(
				2, 2), name='conv2', padding='same', kernel_regularizer=regularizer, kernel_initializer=initializer, use_bias=False)
			x = self.in_lrelu(x)
			
			# stage 3
			x = tf.layers.conv2d(x, filters=512, kernel_size=(4, 4), strides=(
				2, 2), name='conv3', padding='same', kernel_regularizer=regularizer, kernel_initializer=initializer, use_bias=False)
			x = self.in_lrelu(x)
   
			#the final stage
			x = tf.layers.conv2d(x, filters=512, kernel_size=(4, 4), strides=(
				2, 2), name='conv4', padding='same', kernel_regularizer=regularizer, kernel_initializer=initializer, use_bias=False)
			x = self.in_lrelu(x)
	
			#the final shape is 4 x 4 x 512
			return x

	def encode_posi(self, posi, reuse=None):
		with tf.variable_scope('GEN_posi', reuse=reuse):
			x=posi
			normalizer_fn = ly.instance_norm
			regularizer = tf.contrib.layers.l2_regularizer(self.cfg.weight_decay)
			initializer = tf.contrib.layers.xavier_initializer()
			# stage 1
			x = tf.layers.conv2d(x, filters=64, kernel_size=(4, 4), strides=(
				2, 2), name='conv0', kernel_regularizer=regularizer, padding='same', kernel_initializer=initializer, use_bias=False)
			x = self.in_lrelu(x)
			x = tf.layers.conv2d(x, filters=128, kernel_size=(4, 4), strides=(
				2, 2), name='conv1', padding='same', kernel_regularizer=regularizer, kernel_initializer=initializer, use_bias=False)
			x = self.in_lrelu(x)

			# stage 2
			x = tf.layers.conv2d(x, filters=256, kernel_size=(4, 4), strides=(
				2, 2), name='conv2', padding='same', kernel_regularizer=regularizer, kernel_initializer=initializer, use_bias=False)
			x = self.in_lrelu(x)
			
			# stage 3
			x = tf.layers.conv2d(x, filters=512, kernel_size=(4, 4), strides=(
				2, 2), name='conv3', padding='same', kernel_regularizer=regularizer, kernel_initializer=initializer, use_bias=False)
			x = self.in_lrelu(x)
   
			#the final stage
			#x = tf.layers.conv2d(x, filters=512, kernel_size=(4, 4), strides=(
			#	2, 2), name='conv4', padding='same', kernel_regularizer=regularizer, kernel_initializer=initializer, use_bias=False)
			#x = self.in_lrelu(x)
	
			#the final shape is 4 x 4 x 512
			return x

	def gated_deconv(self, x, cnum, ksize=3, stride=1, rate=1,	name='gated_deconv',\
	padding='same',activation=None, initializer=ly.xavier_initializer(),\
	regularizer=None,use_bias=False, training=True, bias_init=tf.zeros_initializer()):
		#the cnum is the output channle number

		x = resize(x, func=tf.image.resize_nearest_neighbor)
		x = self.gated_conv(x, cnum, ksize, stride, rate,  name=name,\
			padding=padding, activation=activation, initializer=ly.xavier_initializer(),\
			regularizer=regularizer,use_bias=use_bias, training=training, 
			bias_init=bias_init)

		return x

	@add_arg_scope
	def gated_conv(self, x, cnum, ksize=3, stride=1, rate=1,  name='gated_conv',\
	padding='same',activation=None, initializer=ly.xavier_initializer(),\
	regularizer=None,use_bias=False, training=True, bias_init=tf.zeros_initializer()):

		#the cnum is the output channle number
		assert padding in ['symmetric', "same", 'refeletc']
		if padding == 'symmetric' or padding == 'refelect':
			p = int(rate*(ksize-1)//2)
			x=tf.pad(x, [[0,0],[p,p], [p, p], [0, 0]], mode = padding) 
			padding = 'valid'

		xin = x
		x = tf.layers.conv2d(xin, filters=cnum, kernel_size=3, strides=stride, 
				name=name, kernel_regularizer=regularizer, padding=padding, 
				kernel_initializer=initializer,dilation_rate=rate,	use_bias=use_bias,
				bias_initializer=bias_init, activation=activation)

		gated_mask = tf.layers.conv2d(xin, filters=cnum, kernel_size=3, strides=stride, 
				name=name+'_mask', activation=tf.nn.sigmoid, 
				kernel_regularizer=regularizer, 
				padding=padding, kernel_initializer=initializer, 
				dilation_rate=rate, use_bias=use_bias,
				bias_initializer=bias_init)

		return x * gated_mask

	def posi_emb(self, posi, reuse=None):
		with tf.variable_scope('GEN_DIS_posiEmbedding', reuse=reuse):
			normalizer_fn = ly.instance_norm
			regularizer = tf.contrib.layers.l2_regularizer(self.cfg.weight_decay)
			initializer = tf.contrib.layers.xavier_initializer()
			# stage 1
			posi_conv = tf.layers.conv2d(posi, filters=64, kernel_size=(4, 4), strides=(
				2, 2), name='posi_conv', kernel_regularizer=regularizer, padding='same', kernel_initializer=initializer)
			posi_conv = self.in_lrelu(posi_conv)
			posi_conv = tf.tile(posi_conv, [self.cfg.batch_size_per_gpu, 1,1,1])
			
			return posi_conv

	def encoder_part(self, images, sketch, posi, reuse=None):
		with tf.variable_scope('GEN', reuse=reuse):
			#encode the position first
			normalizer_fn = ly.instance_norm
			regularizer = tf.contrib.layers.l2_regularizer(self.cfg.weight_decay)
			initializer = tf.contrib.layers.xavier_initializer()
			# stage 1
			x = tf.concat([images, sketch], axis=3)

			x = self.gated_conv(x, cnum=64, ksize=4, stride=2, name='conv0', regularizer=regularizer, initializer=initializer)
			x = self.in_lrelu(x)

			x = tf.concat([x, posi], axis=3)
			x = self.gated_conv(x, cnum=64, ksize=3, stride=1, name='conv0_1', regularizer=regularizer, initializer=initializer)
			x = self.in_lrelu(x)
			
			short_cut0 = x
			x = self.gated_conv(x, cnum=128, ksize=4, stride=2, name='conv1',
					regularizer=regularizer, initializer=initializer)
			x = self.in_lrelu(x)
			short_cut1 = x

			# stage 2
			x = self.convolutional_block(x, kernel_size=3, filters=[
										 64, 64, 256], stage=2, block='a', stride=2)
			x = self.identity_block(
				x, 3, [64, 64, 256], stage=2, block='b')
			x = self.identity_block(
				x, 3, [64, 64, 256], stage=2, block='c')
			short_cut2 = x
			
			# stage 3
			x = self.convolutional_block(x, kernel_size=3, filters=[128, 128, 512],
										 stage=3, block='a', stride=2)
			x = self.identity_block(
				x, 3, [128, 128, 512], stage=3, block='b')
			x = self.identity_block(
				x, 3, [128, 128, 512], stage=3, block='c')
			x = self.identity_block(
				x, 3, [128, 128, 512], stage=3, block='d',)
			short_cut3 = x

			# stage 4
			x = self.convolutional_block(x, kernel_size=3, filters=[
										 256, 256, 1024], stage=4, block='a', stride=2)
			x = self.identity_block(
				x, 3, [256, 256, 1024], stage=4, block='b')
			x = self.identity_block(
				x, 3, [256, 256, 1024], stage=4, block='c')
			x = self.identity_block(
				x, 3, [256, 256, 1024], stage=4, block='d')
			x = self.identity_block(
				x, 3, [256, 256, 1024], stage=4, block='e')
			short_cut4 = x
					
			return short_cut0, short_cut1, short_cut2, short_cut3, short_cut4, x

	#the generation procedure
	def build_reconstruction(self, images, sketch_whole, posi, reuse=None):		
		posi_conv = self.posi_emb(posi)
		left_posi = tf.slice(posi_conv, [0,0,0,0], [self.cfg.batch_size_per_gpu, 64, 64, 64])
		right_posi = tf.slice(posi_conv, [0,0,64,0], [self.cfg.batch_size_per_gpu, 64, 64, 64])
		with tf.variable_scope('GEN', reuse=reuse):
			normalizer_fn = ly.instance_norm
			regularizer = tf.contrib.layers.l2_regularizer(self.cfg.weight_decay)
			initializer = tf.contrib.layers.xavier_initializer()

			#get the left and right sketch 
			left_sketch = tf.slice(sketch_whole, [0,0,0,0], [self.cfg.batch_size_per_gpu, 128, 128, 1])
			right_sketch = tf.slice(sketch_whole, [0,0,128,0],[self.cfg.batch_size_per_gpu, 128, 128, 1])
			
			encoder_out = self.encoder_part(images,left_sketch,left_posi)
			short_cut0, short_cut1, short_cut2, short_cut3, short_cut4, x = encoder_out

			# rct transfer
			train, left_hidden = self.rct(x, right_sketch, right_posi)

			#conduct the gate conv on this stamp
			#first concat the image with the sketch feature from sketch encoder
			#train = tf.concat([train, sketch], axis=3)
			#train = self.gated_conv(train, cnum=1024, regularizer=regularizer)

			# stage -4
			train = tf.concat([short_cut4, train], axis=2)

			train = self.grb(train, 1024, 1, 't4')
			train = self.identity_block(
				train, 3, [256, 256, 1024], stage=-4, block='b', is_relu=True)
			train = self.identity_block(
				train, 3, [256, 256, 1024], stage=-4, block='c', is_relu=True)
			

			#train = ly.conv2d_transpose(train, 512, 4, stride=2,
			#							activation_fn=None, normalizer_fn=normalizer_fn, padding='SAME', weights_initializer=initializer, weights_regularizer=regularizer, biases_initializer=None)
			train = self.gated_deconv(train, cnum=512, activation=None,initializer=initializer, regularizer=regularizer, use_bias=True, bias_init=None, name='gate_deconv1')
			train = normalizer_fn(train)

			sc, kp = tf.split(train, 2, axis=2)
			sc = tf.nn.relu(sc)
			merge = tf.concat([short_cut3, sc], axis=3)
			merge = self.shc(merge, short_cut3, 512, name='shc1')
			merge = self.in_relu(merge)

			train = tf.concat([merge, kp], axis=2)
			# stage -3
			train = self.grb(train, 512, 2, 't3')
			
			train = self.identity_block(
				train, 3, [128, 128, 512], stage=-3, block='b', is_relu=True)
			train = self.identity_block(
				train, 3, [128, 128, 512], stage=-3, block='c', is_relu=True)
			train = self.identity_block(
				train, 3, [128, 128, 512], stage=-3, block='d', is_relu=True)

			#train = ly.conv2d_transpose(train, 256, 4, stride=2,
			#							activation_fn=None, normalizer_fn=normalizer_fn, padding='SAME', weights_initializer=initializer, weights_regularizer=regularizer, biases_initializer=None)
			train = self.gated_deconv(train, cnum=256, activation=None,name='gate_deconv2',
					initializer=initializer, regularizer=regularizer, bias_init=None)
			train = normalizer_fn(train)
			sc, kp = tf.split(train, 2, axis=2)
			sc = tf.nn.relu(sc)
			merge = tf.concat([short_cut2, sc], axis=3)
			merge = self.shc(merge, short_cut2, 256, name='shc2')
			merge = self.in_relu(merge)

			train = tf.concat(
				[merge, kp], axis=2)

			# stage -2
			train = self.grb(train, 256, 4, 't2')
			train = self.identity_block(
				train, 3, [64, 64, 256], stage=-2, block='b', is_relu=True)
			train = self.identity_block(
				train, 3, [64, 64, 256], stage=-2, block='c', is_relu=True)
			train = self.identity_block(
				train, 3, [64, 64, 256], stage=-2, block='d', is_relu=True)
			train = self.identity_block(
				train, 3, [64, 64, 256], stage=-2, block='e', is_relu=True)

			#train = ly.conv2d_transpose(train, 128, 4, stride=2,
			#							activation_fn=None, normalizer_fn=normalizer_fn, padding='SAME', weights_initializer=initializer, weights_regularizer=regularizer, biases_initializer=None)
			train = self.gated_deconv(train, cnum=128, activation=None,name='gate_deconv3',
					initializer=initializer, regularizer=regularizer, bias_init=None)
			train = normalizer_fn(train)

			sc, kp = tf.split(train, 2, axis=2)
			sc = tf.nn.relu(sc)
			merge = tf.concat([short_cut1, sc], axis=3)
			merge = self.shc(merge, short_cut1, 128, name='shc3')
			merge = self.in_relu(merge)

			train = tf.concat(
				[merge, kp], axis=2)
 

			# stage -1

			#train = ly.conv2d_transpose(train, 64, 4, stride=2,
			#							activation_fn=None, normalizer_fn=normalizer_fn, padding='SAME', weights_initializer=initializer, weights_regularizer=regularizer, biases_initializer=None)
			train = self.gated_deconv(train, cnum=64, activation=None,name='gate_deconv4',
					initializer=initializer, regularizer=regularizer, bias_init=None)
			train = normalizer_fn(train)

			sc, kp = tf.split(train, 2, axis=2)
			sc = tf.nn.relu(sc)
			merge = tf.concat([short_cut0, sc], axis=3)
			merge = self.shc(merge, short_cut0, 64, name='shc4')
			merge = self.in_relu(merge)

			train = tf.concat(
				[merge, kp], axis=2)
			# stage -0
			#recon = ly.conv2d_transpose(train, 3, 4, stride=2,
			#							activation_fn=None, padding='SAME', weights_initializer=initializer, weights_regularizer=regularizer, biases_initializer=None)
			recon = self.gated_deconv(train, cnum=3, activation=None,name='gate_deconv5',
					initializer=initializer, regularizer=regularizer, bias_init=None)
			#forward the inverse genrated right part and get the encoder_output
			#EXTRACT THE LEFT PART
			right_part_inv = tf.slice(recon, [0,0,128,0], [self.cfg.batch_size_per_gpu,128, 128, 3])
			right_part_inv = right_part_inv[:,:,::-1, :]
			sketch_inv = right_sketch[:,:,::-1,:]
			right_posi = right_posi[:,:,::-1, :]
			out_right_inv = self.encoder_part(right_part_inv, sketch_inv, right_posi, reuse=True)
			out_right = out_right_inv[-1]

			left_sketch_inv = left_sketch[:,:,::-1, :]
			right_hidden = self.rct(out_right,left_sketch_inv,left_posi[:,:,::-1, :], reuse=True, inverse_right=True)

		return recon, tf.nn.tanh(recon), left_hidden, right_hidden

	#the gate convolution operation
	@add_arg_scope
	def gated_conv_ly(self, x, cnum, ksize=3, stride=1, rate=1, name='self.gated_conv',\
	padding='SAME',activation=tf.nn.relu, initializer=ly.xavier_initializer(),\
	regularizer=None,normalizer=ly.instance_norm,training=True):

		#the cnum is the output channle number
		assert padding in ['SYMMERTRIC', "SAME", 'REFELECT']
		if padding == 'SYMMETRIC' or padding == 'REFELECT':
			p = int(rate*(ksize-1)//2)
			x=tf.pad(x, [[0,0],[p,p], [p, p], [0, 0]], mode = padding) 
			padding = 'VALID'

		xin = x
		x=ly.conv2d(xin, cnum, ksize, stride, rate=rate,\
		activation_fn=activation, padding=padding, \
		weights_regularizer=regularizer,\
		weights_initializer=initializer,normalizer_fn=normalizer)
		
		gated_mask = ly.conv2d(xin, cnum, ksize, stride, rate=rate,\
		activation_fn=tf.nn.sigmoid, padding=padding, weights_regularizer=regularizer,\
		weights_initializer=initializer, normalizer_fn=normalizer)

		return x * gated_mask
	
	def conv_sn(self, x, cnum, ksize, stride, activation=None, normalizer=None, name=''):
		'''
		convolution with spectral normalization operation
		'''
		fan_in = ksize**2 * x.get_shape().as_list()[-1]
		fan_out = ksize**2 * cnum
		stddev = np.sqrt(2./ fan_in)

		w = tf.get_variable(name+'_w',[ksize, ksize, x.get_shape()[-1], cnum],
				initializer=tf.truncated_normal_initializer(stddev=stddev))
		
		x = tf.nn.conv2d(x, spectral_normed_weight(w, update_collection
			=tf.GraphKeys.UPDATE_OPS, name=name+'sn_w'), strides=[1,stride, stride, 1],
			padding='SAME', name=name)
		
		if activation is not None:
			x = activation(x)
		if normalizer is not None:
			x = normalizer(x)

		return x

	def build_adversarial_global(self, img, sketch, posi, reuse=None, name=None):
		bs = img.get_shape().as_list()[0]
		posi_conv = self.posi_emb(posi, reuse=True)

		with tf.variable_scope(name, reuse=reuse):

			def lrelu(x, leak=0.2, name="lrelu"):
				with tf.variable_scope(name):
					f1 = 0.5 * (1 + leak)
					f2 = 0.5 * (1 - leak)
					return f1 * x + f2 * abs(x)
			size = 128
			normalizer_fn = ly.instance_norm
			activation_fn = lrelu
			
			'''right_gate0 = ly.conv2d(right_half_sketch, num_outputs=3, kernel_size=3, stride=1, activation=activation_fn, normalizer_fn = normalizer_fn)
			input0 = tf.concat([left_part, right_gate0], axis=2)

			img = ly.conv2d(input0, num_outputs=size / 2, kernel_size=4,
							stride=2, activation_fn=activation_fn)
			img = ly.conv2d(img, num_outputs=size, kernel_size=4,
							stride=2, activation_fn=activation_fn, normalizer_fn=normalizer_fn)
			img = ly.conv2d(img, num_outputs=size * 2, kernel_size=4,
							stride=2, activation_fn=activation_fn, normalizer_fn=normalizer_fn)
			img = ly.conv2d(img, num_outputs=size * 4, kernel_size=4,
							stride=2, activation_fn=activation_fn, normalizer_fn=normalizer_fn)
			img = ly.conv2d(img, num_outputs=size * 4, kernel_size=4,
							stride=2, activation_fn=activation_fn, normalizer_fn=normalizer_fn)
'''
			input0 = tf.concat([img, sketch], axis=3)

			img = self.conv_sn(input0, cnum=size/2, ksize=4, stride=2, activation=activation_fn, normalizer=normalizer_fn, name='conv2')
            #=======================================================
			img = tf.concat([img, posi_conv], axis=3)

			img = self.conv_sn(img, cnum=size/2, ksize=3, stride=1, activation=activation_fn, normalizer=normalizer_fn, name='conv2_posi')

			img = self.conv_sn(img, cnum=size, ksize=4, stride=2, activation=activation_fn, normalizer=normalizer_fn, name='conv3')
			img = self.conv_sn(img, cnum=size*2, ksize=4, stride=2, activation=activation_fn, normalizer=normalizer_fn, name='conv4')
			img = self.conv_sn(img, cnum=size*4, ksize=4, stride=2, activation=activation_fn, normalizer=normalizer_fn, name='conv5')
			img = self.conv_sn(img, cnum=size*4, ksize=4, stride=2, activation=activation_fn, normalizer=normalizer_fn, name='conv6')
			
			#the first convolution block
			logit = ly.fully_connected(tf.reshape(
				img, [bs, -1]), 1, activation_fn=None)
			
			return logit

	def build_adversarial_local(self, img, sketch_whole, posi, reuse=None, name=None):
		bs = img.get_shape().as_list()[0]
		posi_conv = self.posi_emb(posi, reuse=True)
		left_posi = tf.slice(posi_conv, [0,0,0,0], [self.cfg.batch_size_per_gpu, 64, 64, 64])
		right_posi = tf.slice(posi_conv, [0,0,64,0], [self.cfg.batch_size_per_gpu, 64, 64, 64])

		with tf.variable_scope(name, reuse=reuse):
			def lrelu(x, leak=0.2, name="lrelu"):
				with tf.variable_scope(name):
					f1 = 0.5 * (1 + leak)
					f2 = 0.5 * (1 - leak)
					return f1 * x + f2 * abs(x)
			#build the rigth half part
			#img = tf.slice(img_whole,[0,0,128,0], [self.cfg.batch_size,128,128,3])
			size = 128
			normalizer_fn = ly.instance_norm
			activation_fn = lrelu
			sketch = tf.slice(sketch_whole, [0,0,128,0],[self.cfg.batch_size_per_gpu, 128,128,1])
			img = tf.concat([img,sketch], axis=3)
			#img = self.gated_conv(img,cnum=3, ksize=3, stride=1, activation=activation_fn, normalizer=None)
			'''img = ly.conv2d(img, num_outputs=3, kernel_size=3, stride=1, activation_fn=activation_fn)
			img = ly.conv2d(img, num_outputs=size / 2, kernel_size=4,
							stride=2, activation_fn=activation_fn)
			img = ly.conv2d(img, num_outputs=size, kernel_size=4,
							stride=2, activation_fn=activation_fn, normalizer_fn=normalizer_fn)
			img = ly.conv2d(img, num_outputs=size * 2, kernel_size=4,
							stride=2, activation_fn=activation_fn, normalizer_fn=normalizer_fn)
			img = ly.conv2d(img, num_outputs=size * 2, kernel_size=4,
							stride=2, activation_fn=activation_fn, normalizer_fn=normalizer_fn)
			img = ly.conv2d(img, num_outputs=size*4, kernel_size=4, stride=2, activation_fn=activation_fn, normalizer_fn = normalizer_fn)
			'''
			img = self.conv_sn(img, cnum=size/2, ksize=4, stride=2, activation=activation_fn, name='conv1')
            #===================================
			img = tf.concat([img, right_posi], axis=3)
			img = self.conv_sn(img, cnum=size/2, ksize=3, stride=1, activation=activation_fn, name='conv1_1')

			img = self.conv_sn(img, cnum=size, ksize=4, stride=2, activation=activation_fn,name='conv2')
			img = self.conv_sn(img, cnum=size*2, ksize=4, stride=2, activation=activation_fn, normalizer=normalizer_fn, name='conv3')
			img = self.conv_sn(img, cnum=size*2, ksize=4, stride=2, activation=activation_fn, normalizer=normalizer_fn, name='conv4')

			#img = self.conv_sn(img, cnum=size*4, ksize=4, stride=2,activation=activation_fn, normalizer=normalizer_fn, name='conv5')
			logit = ly.fully_connected(tf.reshape(
				img, [bs, -1]), 1, activation_fn=None)

			#========================================================================

		return logit, img
