import torch
import torch.utils.data as data
from fid.fid import calculate_fid_given_paths
from inception_score.inception_score import inception_score
import torchvision.transforms as transforms
from PIL import Image
import pathlib
import argparse
import os

parser = argparse.ArgumentParser(description='Eval modeling ...')
# experiment
#parser.add_argument('--exp-index', type=int, default=2)
parser.add_argument('--gen_image_path', type=str, default='')
parser.add_argument('--gen_mode', type=str,default='m0')
parser.add_argument('--use_gpus', type=str, default='')

args = parser.parse_args()

os.environ['CUDA_VISIBLE_DEVICES'] = args.use_gpus

def FID(batch_size=32, cuda=True, dims=2048, gen_mode=''):
	real_path = 'data/raw_test_image/'
	gen_path = args.gen_image_path

	paths = [real_path, gen_path]

	return calculate_fid_given_paths(paths, batch_size=batch_size, cuda=cuda, dims=dims, gen_mode=gen_mode)


def IS(gen_mode, cuda=True, batch_size=2, resize=True, splits=10):
	dataset = GEN_Data(gen_mode)

	return inception_score(imgs=dataset,cuda=cuda,batch_size=batch_size,
	resize=resize,splits=splits)

#define the dataset
class GEN_Data(data.Dataset):
	def __init__(self, gen_mode):
		self.gen_mode = gen_mode
		self.root_path = args.gen_image_path
		
		path = pathlib.Path(self.root_path)
		files = list(path.glob(gen_mode+'*.jpg')) + list(path.glob(gen_mode+'*.png'))
		
		self.images = files
		self.len = len(files)
		mean = [0.485, 0.456, 0.406]
		std = [0.229, 0.224, 0.225]
		self.trans = transforms.Compose([transforms.ToTensor(), transforms.Normalize(mean=mean, std=std)]) 
		print('images num: {}, gen mode: {}'.format(self.len, gen_mode))


	def __getitem__(self, index):
		
		img = self.images[index]
		image = Image.open(img).convert('RGB')
		
		img_tensor = self.trans(image)

		return img_tensor

	def __len__(self):
		return self.len

if __name__ == '__main__':
	print('calcualte the fid score ...')
	fid = FID(gen_mode=args.gen_mode)
	print('done')
	print('FID Distance', fid)
	
	print('calculate inception score ...')
	is_score = IS(gen_mode=args.gen_mode)
	print('done')

	print('IS Score: ', is_score)
